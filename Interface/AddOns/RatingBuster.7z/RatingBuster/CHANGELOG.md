# RatingBuster

## [1.4.3](https://github.com/raethkcj/RatingBuster/tree/1.4.3) (2022-06-25)
[Full Changelog](https://github.com/raethkcj/RatingBuster/compare/1.4.2...1.4.3) [Previous Releases](https://github.com/raethkcj/RatingBuster/releases)

- Don't detect grimoires as containing nested recipes (Fixes #80)  
- Bump TOC  
- Bump TOC  